# NO NPC FiveM Script

## Description

- Hi, this is one of my FiveM scripts, it stop the NPC spawn.
- It reduce MS, increases FPS and reduce CPU, RAM & GPU usage.

### Download & instalation

#### Using GIT

```sh
cd resources/
git clone https://github.com/ZAD4YTV/NoNPC [local]/NoNPC
```

#### Manualy

- Download <https://codeload.github.com/ZAD4YTV/NoNPC/zip/main>
- Put it in the `[local]` repository

### Instalation

- Add `start NoNPC` to your `server.cfg`.

#### Legal

##### License

- GNU License GPL V3.0
- Read the license in this URL: <https://github.com/ZAD4YTV/NoNPC/blob/main/LICENSE>
