fx_version 'cerulean'

game 'gta5'
author 'ZAD4Y'
description 'No NPC'
version '1.0.0'

client_script 'main.lua'